package Exercicio03_v4;

public class Resultado {
    public double mensalidade;
    public String curso;
    public String programaBolsa;
    public double desconto;

}