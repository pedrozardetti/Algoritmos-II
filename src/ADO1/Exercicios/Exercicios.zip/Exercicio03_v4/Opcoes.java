package Exercicio03_v4;

public class Opcoes {
    public int codCurso;
    public int codBolsa;
}