package Exercicio02_v4;

public class Resultado {

    public double total;
    public double juros;

}