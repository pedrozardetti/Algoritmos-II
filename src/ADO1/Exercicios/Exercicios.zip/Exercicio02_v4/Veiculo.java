package Exercicio02_v4;

class Veiculo {
  
  public double preco;
  public int parcelas;

}
