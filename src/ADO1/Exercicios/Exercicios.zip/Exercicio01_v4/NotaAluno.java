package Exercicio01_v4;

class NotaAluno {

  public double n1;
  public double n2;
  public double n3;
  public int faltas;

  

}
