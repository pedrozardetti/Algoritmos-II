package Exercicio01_v4;

public class Resultado {

  public double media;
  public String situacao;
}
